<html>

<head>
    <link href="/css/bootstrap.min.css" rel="stylesheet">
    <script src="/js/bootstrap.bundle.min.js"></script>
    @yield('style')
</head>
<body>
@yield('content-meta')

</body>
</html>
