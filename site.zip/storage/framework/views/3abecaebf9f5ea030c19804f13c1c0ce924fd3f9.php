

<?php $__env->startSection('content-meta'); ?>

    <div class="container-fluid">
        <nav class="navbar navbar-expand-lg bg-light">
            <div class="container-fluid">
                <?php if(auth()->guard()->check()): ?>
                <a class="navbar-brand" href="#">Virl MicroFinance</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse d-flex justify-content-end" id="navbarNavAltMarkup">
                    <div class="navbar-nav">
                        <a class="nav-link active" aria-current="page" href="<?php echo e(route('show-dashboard')); ?>">Dashboard</a>
                        <?php if(auth()->user()->access_level=='admin'): ?>
                        <a class="nav-link" href="<?php echo e(route('show-users')); ?>">Users</a>
                        <?php endif; ?>
                        <a class="nav-link" href="<?php echo e(route('show-profile')); ?>">Edit Profile</a>
                        <a class="nav-link" href="<?php echo e(route('logout')); ?>">Logout</a>

                    </div>



                </div>
                <?php endif; ?>
            </div>
        </nav>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <?php echo $__env->yieldContent('scripts'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\samuel\Documents\github\WhatsappChatbot\resources\views/layouts/master.blade.php ENDPATH**/ ?>