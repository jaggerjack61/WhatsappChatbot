

<?php $__env->startSection('content'); ?>
    <div class="p-5 bg-opacity-10" style="background-image:url('/img/login.jpg')">
    <div class="card m-5 justify-content-center align-items-center" style="height: 100%;opacity:0.95">
        <h1 class="card-title text-center">
            Virl Micro Finances
        </h1>
        <h3>
        <?php if(session()->has('error')): ?>
            <div class="bg-danger text-white">

                <?php echo e(session()->get('error')); ?>

            </div>
        <?php elseif(session()->has('success')): ?>
            <div class="bg-success">

                <?php echo e(session()->get('success')); ?>

            </div>
        <?php endif; ?></h3>
    <form  action="<?php echo e(route('login')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="inputEmail">Email</label>
            <input type="text" name="email" class="form-control" id="inputEmail" placeholder="Email">
        </div>
        <div class="form-group">
            <label for="inputPassword">Password</label>
            <input type="password" name="password" class="form-control" id="inputPassword" placeholder="Password">
        </div>
        <button type="submit" class="btn btn-primary m-1">Sign in</button>
    </form>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\samuel\Documents\github\WhatsappChatbot\resources\views/auth/login.blade.php ENDPATH**/ ?>