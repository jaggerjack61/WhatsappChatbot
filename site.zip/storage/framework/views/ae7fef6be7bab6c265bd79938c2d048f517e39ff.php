<?php $__env->startSection('content'); ?>
    <h3>
        <?php if(session()->has('error')): ?>
            <div class="bg-danger text-white" id="notice">

                <?php echo e(session()->get('error')); ?>

            </div>
            <script>
                await new Promise(r => setTimeout(r, 5000));
                document.getElementById('notice').style.display = 'none';
            </script>
        <?php elseif(session()->has('success')): ?>
            <div class="bg-success" id="notice">

                <?php echo e(session()->get('success')); ?>


            </div>
            <script>
                await new Promise(r => setTimeout(r, 5000));
                document.getElementById('notice').style.display = 'none';
            </script>
        <?php endif; ?></h3>
        <h1>Details</h1>
        <card>
            <form action="<?php echo e(route('update-user')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="userId" value="<?php echo e($user->id); ?>"/>
                <div class="form-group">
                    <label for="inputEmail">Email</label>
                    <input type="text" name="email" value="<?php echo e($user->email); ?>" class="form-control" id="inputEmail" placeholder="Email">
                </div>
                <div class="form-group">
                    <label for="inputEmail">Name</label>
                    <input type="text" name="name" class="form-control" value="<?php echo e($user->name); ?>" id="inputEmail" placeholder="Email">
                </div>



                <button type="submit" class="btn btn-primary m-1">Save</button>
            </form>
        </card>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\samuel\Documents\github\WhatsappChatbot\resources\views/settings/profile.blade.php ENDPATH**/ ?>