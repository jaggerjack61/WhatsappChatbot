<html>

<head>
    <link href="/css/bootstrap.min.css" rel="stylesheet">
    <script src="/js/bootstrap.bundle.min.js"></script>
    <?php echo $__env->yieldContent('style'); ?>
</head>
<body>
<?php echo $__env->yieldContent('content-meta'); ?>

</body>
</html>
<?php /**PATH C:\Users\samuel\Documents\github\WhatsappChatbot\resources\views/layouts/base.blade.php ENDPATH**/ ?>