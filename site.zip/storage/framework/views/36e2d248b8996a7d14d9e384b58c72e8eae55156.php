<?php $__env->startSection('content'); ?>
    <?php if(auth()->user()->access_level=='admin'): ?>
    <h3>
        <?php if(session()->has('error')): ?>
            <div class="bg-danger text-white" id="notice">

                <?php echo e(session()->get('error')); ?>

            </div>
            <script>
                await new Promise(r => setTimeout(r, 5000));
                document.getElementById('notice').style.display = 'none';
            </script>
        <?php elseif(session()->has('success')): ?>
            <div class="bg-success" id="notice">

                <?php echo e(session()->get('success')); ?>


            </div>
            <script>
                await new Promise(r => setTimeout(r, 5000));
                document.getElementById('notice').style.display = 'none';
            </script>
        <?php endif; ?></h3>

        <a href="#" class="btn btn-primary m-2" data-bs-toggle="modal" data-bs-target="#addUserModal">New User</a>

    <table class="table table-bordered">
        <thead>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Access Level</th>
            <th>Status</th>
            <th>Action</th>

        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e(strtoupper($user->access_level)); ?></td>
                    <td><?php echo e(strtoupper($user->status)); ?></td>

                    <td><button class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#editUserModal" onclick="
                    document.getElementById('userId').value='<?php echo e($user->id); ?>';
                    document.getElementById('editName').value='<?php echo e($user->name); ?>';
                    document.getElementById('editEmail').value='<?php echo e($user->email); ?>';">Edit</button>

                    <?php if($user->access_level == 'admin'): ?>
                        <a href="<?php echo e(route('demote',[$user->id])); ?>" class="btn btn-sm btn-danger">Demote to User</a>
                    <?php elseif($user->access_level == 'user'): ?>
                        <a href="<?php echo e(route('promote',[$user->id])); ?>" class="btn btn-sm btn-success">Promote to Admin</a>
                    <?php endif; ?>

                    <?php if($user->status == 'active'): ?>
                        <a href="<?php echo e(route('deactivate',[$user->id])); ?>" class="btn btn-sm btn-danger">Deactivate</a>
                    <?php elseif($user->status == 'inactive'): ?>
                        <a href="<?php echo e(route('activate',[$user->id])); ?>" class="btn btn-sm btn-success">Activate</a>
                    <?php endif; ?>
                        </td>
                </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>


        <div class="modal fade" id="addUserModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Add User</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo e(route('save-user')); ?>" method="post">
                            <?php echo csrf_field(); ?>

                            <div class="form-group">
                                <label for="inputEmail">Email</label>
                                <input type="text" name="email" class="form-control" id="inputEmail" placeholder="Email">
                            </div>
                            <div class="form-group">
                                <label for="inputEmail">Name</label>
                                <input type="text" name="name" class="form-control" id="inputEmail" placeholder="Email">
                            </div>
                            <div class="form-group">
                                <label for="inputPassword">Password</label>
                                <input type="password" name="password" class="form-control" id="inputPassword" placeholder="Password">
                            </div>
                            <div class="form-group">
                                <label for="inputPassword">Password</label>
                                <input type="password" name="passwordConfirmation" class="form-control" id="inputPassword" placeholder="Confirm Password">
                            </div>

                            <button type="submit" class="btn btn-primary m-1">Save</button><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </form>
                    </div>

                </div>
            </div>
        </div>


    <div class="modal fade" id="editUserModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit User</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('update-user')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="userId" class="form-control" id="userId">
                        <div class="form-group">
                            <label for="inputEmail">Email</label>
                            <input type="text" name="email" class="form-control" id="editEmail" placeholder="Email">
                        </div>
                        <div class="form-group">
                            <label for="inputEmail">Name</label>
                            <input type="text" name="name" class="form-control" id="editName" placeholder="Email">
                        </div>



                        <button type="submit" class="btn btn-primary m-1">Update</button><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    </form>
                </div>

            </div>
        </div>
    </div>
    <?php else: ?>
        <h2>You do not have permission to view this page.</h2>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\samuel\Documents\github\WhatsappChatbot\resources\views/settings/users.blade.php ENDPATH**/ ?>