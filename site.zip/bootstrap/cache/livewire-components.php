<?php return array (
  'dashboard' => 'App\\Http\\Livewire\\Dashboard',
  'dashborad' => 'App\\Http\\Livewire\\Dashborad',
);